-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2019 at 06:35 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oopcas13`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategorije`
--

CREATE TABLE `kategorije` (
  `kategorija` varchar(255) NOT NULL,
  `opis` text NOT NULL,
  `trajanje` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategorije`
--

INSERT INTO `kategorije` (`kategorija`, `opis`, `trajanje`) VALUES
('A', 'motocikl', 5),
('B', 'automobil', 10),
('C', 'kamion', 5),
('D', 'autobus', 3);

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `idkorisnika` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`idkorisnika`, `ime`, `prezime`, `email`, `username`, `password`) VALUES
(1, 'Ana', 'Todorovic', 'superana@gmail.com', 'ana', 'ana'),
(2, 'Maja', 'Vejapi', 'makimaki@gmail.com', 'maki', 'maki'),
(4, 'Sloba', 'RISTIC', 'sloba@gmail.com', 'sloba', 'sloba'),
(5, 'Luka', 'Luka', 'luka@mail.com', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `proizvodjaci`
--

CREATE TABLE `proizvodjaci` (
  `imeproizvodjaca` varchar(255) NOT NULL,
  `zemljaporekla` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proizvodjaci`
--

INSERT INTO `proizvodjaci` (`imeproizvodjaca`, `zemljaporekla`) VALUES
('Audi', 'Nemacka'),
('Fiat', 'Italija'),
('Honda', 'Japan'),
('Iveco', 'Italija'),
('Mercedes', 'Nemacka'),
('Peugeot', 'Francuska'),
('Reno', 'Francuska'),
('Scania', 'Svedska'),
('Suzuki', 'Japan'),
('Toyota', 'Japan'),
('Volkswagen', 'Nemacka'),
('Volvo', 'Svedska'),
('Zastava', 'Srbija');

-- --------------------------------------------------------

--
-- Table structure for table `vozaci`
--

CREATE TABLE `vozaci` (
  `idvozaca` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `godiste` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vozaci`
--

INSERT INTO `vozaci` (`idvozaca`, `ime`, `prezime`, `godiste`) VALUES
(8, 'Nikola', 'Nikic', 1991),
(9, 'Luka', 'Lukic', 2004),
(10, 'Ana', 'Tomic', 2003),
(11, 'Djordje', 'Peric', 1990),
(12, 'Maja', 'Nikolic', 1987),
(13, 'Bojan', 'Djokic', 2001),
(14, 'Aca', 'Peric', 2004),
(15, 'Joca', 'Jokic', 1999),
(16, 'Natasa', 'Antic', 1970),
(17, 'Bojan', 'Antic', 1999),
(18, 'Dejan', 'Popovic', 1990),
(20, 'suzana', 'suki', 1998),
(21, 'milan', 'tot', 1971),
(23, 'stojan', 'stojic', 1974),
(24, 'nikola', 'ristic', 1978),
(25, 'uros', 'rajic', 1992),
(28, 'marko', 'markovic', 1978),
(29, 'boris', 'bokic', 1978),
(33, 'ana', 'ristic', 1979),
(34, 'ana', 'jakic', 1977),
(35, 'lazar', 'bokic', 1982),
(38, 'sofija ', 'vejapi', 1999),
(39, 'suzana', 'suzic', 1992);

-- --------------------------------------------------------

--
-- Table structure for table `vozila`
--

CREATE TABLE `vozila` (
  `idvozila` int(11) NOT NULL,
  `imeproizvodjaca` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `kategorija` varchar(255) NOT NULL,
  `godiste` int(11) NOT NULL,
  `cena` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vozila`
--

INSERT INTO `vozila` (`idvozila`, `imeproizvodjaca`, `model`, `kategorija`, `godiste`, `cena`) VALUES
(2, 'Fiat', 'Ducato', 'C', 2001, 2016),
(3, 'Volvo', 'FH', 'D', 2010, 301),
(4, 'Peugeot', 'speedfight', 'A', 1500, 2012),
(5, 'Suzuki', 'swift', 'B', 2009, 4500),
(7, 'Reno', 'trafic', 'C', 2011, 7500),
(8, 'Peugeot', 'master', 'C', 2008, 8000),
(9, 'Mercedes', 'actros', 'C', 2006, 11000),
(10, 'Scania', 'p320', 'D', 2007, 6000),
(11, 'Iveco', '65cib', 'D', 2009, 2300),
(12, 'Volkswagen', 'LT', 'D', 2003, 950),
(13, 'Peugeot', 'UH8', 'D', 2000, 1050),
(14, 'Peugeot', 'A8', 'A', 2009, 800),
(15, 'Peugeot', '577', 'B', 2004, 1400),
(16, 'Mercedes', 'H7', 'B', 2012, 22000),
(17, 'Mercedes', 'I9', 'A', 2013, 23000),
(18, 'Audi', 'K9', 'A', 1999, 1001),
(19, 'Audi', '400', 'C', 2005, 2000),
(20, 'Audi', 'FE', 'D', 1985, 700),
(21, 'Fiat', 'K7', 'A', 2002, 4300),
(22, 'Fiat', 'LP4', 'B', 2005, 1700),
(26, 'Iveco', 'DW', 'C', 1995, 3600),
(27, 'Suzuki', 'NLO', 'A', 2017, 1200),
(28, 'Suzuki', 'ZQ', 'C', 2016, 1480),
(29, 'Suzuki', 'M1', 'D', 2015, 1480),
(30, 'Honda', '300', 'A', 2004, 1050),
(31, 'Honda', 'VZ', 'C', 2008, 25000),
(34, 'Fiat', 'a5', 'A', 2000, 300),
(35, 'Audi', 'a1', 'B', 2000, 500),
(37, 'Suzuki', 's8', 'B', 1976, 600),
(38, 'Zastava', 'i1000', 'B', 1998, 200),
(43, 'Audi', 'a100', 'C', 1978, 1000),
(44, 'Fiat', 'ttr', 'A', 1965, 500),
(45, 'Zastava', 'wer', 'B', 1985, 700),
(46, 'Honda', 'c4', 'A', 1998, 200),
(48, 'Toyota', 'm8', 'D', 1980, 700),
(49, 'Audi', 'TT', 'B', 2009, 8000),
(50, 'Audi', 'A3', 'C', 2009, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `vozilavozaci`
--

CREATE TABLE `vozilavozaci` (
  `idvozila` int(11) NOT NULL,
  `idvozaca` int(11) NOT NULL,
  `vremedodele` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vozilavozaci`
--

INSERT INTO `vozilavozaci` (`idvozila`, `idvozaca`, `vremedodele`) VALUES
(2, 9, '2019-03-24 17:42:13'),
(2, 15, '2019-06-25 16:25:57'),
(2, 20, '2019-03-13 21:46:12'),
(2, 21, '2019-03-13 23:31:43'),
(3, 15, '2019-03-17 01:10:37'),
(5, 21, '2019-03-16 23:36:21'),
(7, 8, '2019-01-21 18:05:42'),
(8, 18, '2019-03-17 01:06:22'),
(9, 11, '2019-01-22 22:32:54'),
(9, 15, '2019-01-22 22:28:05'),
(15, 15, '2019-01-22 22:38:23'),
(16, 21, '2019-03-14 22:41:19'),
(19, 9, '2019-01-22 22:36:21'),
(20, 10, '2019-01-22 22:28:05'),
(20, 12, '2019-01-22 22:36:57'),
(21, 13, '2019-01-22 22:36:57'),
(22, 8, '2019-01-22 22:39:12'),
(22, 13, '2019-01-22 22:39:12'),
(26, 11, '2019-01-22 22:32:54'),
(30, 9, '2019-01-22 22:31:12'),
(30, 12, '2019-01-22 22:30:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategorije`
--
ALTER TABLE `kategorije`
  ADD PRIMARY KEY (`kategorija`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`idkorisnika`);

--
-- Indexes for table `proizvodjaci`
--
ALTER TABLE `proizvodjaci`
  ADD PRIMARY KEY (`imeproizvodjaca`);

--
-- Indexes for table `vozaci`
--
ALTER TABLE `vozaci`
  ADD PRIMARY KEY (`idvozaca`);

--
-- Indexes for table `vozila`
--
ALTER TABLE `vozila`
  ADD PRIMARY KEY (`idvozila`),
  ADD KEY `imeproizvodjaca` (`imeproizvodjaca`),
  ADD KEY `kategorija` (`kategorija`);

--
-- Indexes for table `vozilavozaci`
--
ALTER TABLE `vozilavozaci`
  ADD PRIMARY KEY (`idvozila`,`idvozaca`),
  ADD KEY `idvozila` (`idvozila`),
  ADD KEY `idvozaca` (`idvozaca`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `idkorisnika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vozaci`
--
ALTER TABLE `vozaci`
  MODIFY `idvozaca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `vozila`
--
ALTER TABLE `vozila`
  MODIFY `idvozila` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vozila`
--
ALTER TABLE `vozila`
  ADD CONSTRAINT `vozila_ibfk_1` FOREIGN KEY (`imeproizvodjaca`) REFERENCES `proizvodjaci` (`imeproizvodjaca`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vozila_ibfk_2` FOREIGN KEY (`kategorija`) REFERENCES `kategorije` (`kategorija`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vozilavozaci`
--
ALTER TABLE `vozilavozaci`
  ADD CONSTRAINT `vozilavozaci_ibfk_1` FOREIGN KEY (`idvozila`) REFERENCES `vozila` (`idvozila`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vozilavozaci_ibfk_2` FOREIGN KEY (`idvozaca`) REFERENCES `vozaci` (`idvozaca`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
